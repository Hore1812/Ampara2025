<?php
$host = 'localhost';
$db   = 'u505676278_inet_ampara';
$user = 'u505676278_intranet';
$pass = 'Ampara@2025';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>